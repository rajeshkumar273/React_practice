
import './App.css';
import Sample from './components/onclick';
import App1 from './components/useStateDemo';
import UseEffect  from './components/useEffectDemo';
import EventHandler  from './components/EventHandler';
import OnSubmitDemo from './components/onsubmit'
import Map from './components/Map'
//import FilterFunction from './components/FilterFunction';
import {LoginForm} from './components/LoginForm'
import {FetchAPI} from './components/FetchAPI'
import {AxiosLibrary} from './components/AxiosLibrary'
import Navbar from './components/Navbar';
import {BrowserRouter,Route,Routes} from 'react-router-dom';
import Home from './components/Home';
import Dashboard from './components/Dashboard';
import About from './components/About';
import PathParams from './components/PathParams';
import BootStrap from './components/BootStrap';
import SearchFilter from './components/SearchFilter';
import UseContext from './components/UseContext';



function App() {
  return (
   
    <div>
    {/*
    <Sample></Sample>
    <App1> </App1> 
    <UseEffect></UseEffect>
    <EventHandler></EventHandler> <br></br>
    <OnSubmitDemo></OnSubmitDemo> <br></br>
    <Map></Map>
     <FilterFunction></FilterFunction> 
    <LoginForm />
    <FetchAPI/>
    <AxiosLibrary />
    */ }

    <BrowserRouter>
        <Navbar />
            <Routes>
              <Route path="/" element={<Home/>} />
              <Route path="/dashboard" element={<Dashboard></Dashboard>} />
              <Route path="/about" element={<About/>}/>
              <Route path="/pathparams/:name" element={<PathParams/>}/>
           </Routes>
    </BrowserRouter> <br></br>
    <BootStrap />
    <SearchFilter />
    <UseContext></UseContext>
    </div>
  );
}

export default App;
