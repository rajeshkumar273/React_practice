import React from 'react';
import ComponentB from './ComponentB';
import ComponentC from './ComponentC'

export const UserContext=React.createContext();


const UseContext =() => {

    return (
        <div>
            <center>
            <UserContext.Provider value={"Rajesh TechHub"}>
                <ComponentC />
                <ComponentB />
            </UserContext.Provider>

            </center>
        </div>
    )
}

export default UseContext


