import React from 'react';

function Filter() {

    const names =['John','James','Paul','Ringo','George']
    const arr=[10,20,30,40,50,60,70]
    const filtered=names.filter(name =>name.includes('J'))
    const arrFiltered=arr.filter(number => number>40)
    return (
        <div>
        <center>
            {
            filtered.map(item => <li>{item}</li>)   
        }
        
        {
            arrFiltered.map(number =><li>{number}</li>)
        }
        </center>
        </div>
    );


}

export default Filter;






