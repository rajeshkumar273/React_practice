import React from 'react';

const ComponentC =() => {

    return (
        <div>
            <h1> Content from Component C </h1>
        </div>
    )
}

export default ComponentC

