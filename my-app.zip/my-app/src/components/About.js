import React from 'react'

const About = () => {
  return (
    <div>
    <center>
      <h1> Welcome to About Page.!!</h1>
    </center>
    </div>
  )
}

export default About
