import React from 'react';

const Sample = () => {

    return(

        <center>
            <h1> Welcome to Rajesh TechHub!....Kumar </h1>

            <button onClick={() =>console.log("clicked")}> Click for Admission</button>
            <h1 onClick={() =>console.log("clicked")}> Click for Admission</h1>
        </center>

    )
}

export default Sample;

