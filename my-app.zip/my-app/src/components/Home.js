import React,{useState} from 'react';
import {Navigate} from 'react-router-dom';
import RainEffect from './raineffect.jpeg';
import AudioFile from'./Sakuya2.mp3';
import VideoFile from './greenary.mp4';

const Home = () => {

  const [auth,setAuth] =useState(false);
  if(auth){

    return <Navigate to='/dashboard'/>
  }
  return (
    <div>
      <center>
      <h1> Welcome to Home Page!!</h1>
      <img src={RainEffect} height="375px" width="550px" /> <br></br><br></br>
      <audio controls>
      <source src={AudioFile} type="audio/ogg"></source>
      </audio><br></br> 
      <video height="375px"  width="550px" controls>
      <source src={VideoFile} type="video/mp4">

      </source>
      </video><br></br>

      <button onClick={() => setAuth(true)}>Login</button> 
      </center>
    </div>
  )
}

export default Home
