import React from 'react';
import {UserContext} from './UseContext';
const ComponentB = () => {

    return (
        <div>
            <center>
                <h1>Content from Component B</h1>
                <UserContext.Consumer>
                    {value => <div>{value}</div>}
                </UserContext.Consumer>

            </center>
        </div>
    )
}

export default ComponentB