import React from 'react'
import {useParams} from 'react-router-dom';


const PathParams = ({match}) => {
  return (
    <div>
      <center>
        <h1> Path params Profile name is:{match.useparams.name}</h1>
      </center>
    </div>
  )
}

export default PathParams
