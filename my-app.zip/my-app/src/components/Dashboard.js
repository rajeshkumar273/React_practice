import React from 'react'
import {useNavigate} from 'react-router-dom';

const Dashboard = () => {
  let navigate=useNavigate();
  return (
    <div>
    <center>
      <h1> Displaying Dashboard Content.!!</h1>
      <button onClick={() => navigate('/about')}>useNavigateToAboutPage</button>
      </center>
    </div>
  )
}

export default Dashboard
