import React,{useState} from 'react';

const App1 = () => {

   // const [name,setName]= useState("TechHub");

      const [count,setCount]=useState(0)

    return (

        
         <div>
         <center>
                    <h1>{count}</h1>
                    <button onClick={ () => setCount(count+1)}>Change</button>

        </center>
        </div>
    );
}

export default App1;